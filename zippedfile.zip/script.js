document.addEventListener('DOMContentLoaded', function() {
    let cart = [];
    let completedOrders = []; // New array to store completed orders

    // Get DOM elements
    const cartCountElement = document.getElementById('cartCount');
    const openModalBtn = document.getElementById('openModalBtn');
    const closeOrderModalBtn = document.getElementById('closeOrderModalBtn');
    const closeSubscribeBtn = document.getElementById('closeSubscribeBtn');
    const orderModal = document.getElementById('orderModal');
    const subscribeModal = document.getElementById('subscribeModal');
    const welcomeModal = document.getElementById('welcomeModal');
    const welcomeBtn = document.getElementById('welcomeBtn');
    const modalCartItems = document.getElementById('modalCartItems');
    const modalCartTotal = document.getElementById('modalCartTotal');
    const orderForm = document.getElementById('orderForm');
    const subscribeForm = document.getElementById('subscribeForm');
    const completedOrdersContainer = document.getElementById('completedOrdersContainer'); // New element

    // Account form elements
    const showSignupLink = document.getElementById('show-signup');
    const showLoginLink = document.getElementById('show-login');
    const loginFormWrapper = document.getElementById('login-form-wrapper');
    const signupFormWrapper = document.getElementById('signup-form-wrapper');
    
    // Show welcome modal on page load
    setTimeout(() => {
        welcomeModal.classList.add('active');
    }, 500);

    welcomeBtn.addEventListener('click', () => {
        welcomeModal.classList.remove('active');
    });

    // Parallax Effect
    document.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        document.querySelectorAll('.bg-element, .bg-logo').forEach(element => {
            const speed = element.getAttribute('data-speed');
            const translateY = -scrolled * parseFloat(speed) * 0.05;
            element.style.transform = `translateY(${translateY}px)`;
        });
    });

    // Add to Cart Functionality
    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.addEventListener('click', function() {
            const productCard = this.closest('.product-card');
            const productName = productCard.getAttribute('data-name');
            const productPrice = parseFloat(productCard.getAttribute('data-price'));
            const productImage = productCard.querySelector('img').src;
            
            const existingItem = cart.find(item => item.name === productName);
            
            if (existingItem) {
                existingItem.quantity++;
            } else {
                cart.push({
                    name: productName,
                    price: productPrice,
                    quantity: 1,
                    image: productImage
                });
            }
            
            updateCartDisplay();
            alert(`${productName} added to cart!`);
        });
    });
    
    function updateCartDisplay() {
        cartCountElement.textContent = cart.reduce((total, item) => total + item.quantity, 0);
        
        modalCartItems.innerHTML = '';
        let total = 0;
        
        if (cart.length === 0) {
            modalCartItems.innerHTML = '<p style="text-align: center; color: var(--text-gray); margin-top: 20px;">Your cart is empty.</p>';
        } else {
            cart.forEach((item, index) => {
                const itemElement = document.createElement('div');
                itemElement.classList.add('cart-item');
                itemElement.innerHTML = `
                    <div class="cart-item-info">
                        <img src="${item.image}" alt="${item.name}">
                        <div class="cart-item-details">
                            <div class="cart-item-name">${item.name}</div>
                            <span>Qty: ${item.quantity}</span>
                        </div>
                    </div>
                    <div class="cart-item-price">$${(item.quantity * item.price).toFixed(2)}</div>
                    <button class="remove-item-btn" data-index="${index}">Remove</button>
                `;
                modalCartItems.appendChild(itemElement);
                total += item.quantity * item.price;
            });
        }
        
        modalCartTotal.textContent = `Total: $${total.toFixed(2)}`;

        // Add event listeners for new remove buttons
        document.querySelectorAll('.remove-item-btn').forEach(button => {
            button.addEventListener('click', function() {
                const itemIndex = this.getAttribute('data-index');
                cart.splice(itemIndex, 1);
                updateCartDisplay();
            });
        });
    }

    // New function to generate a text-based order summary
    function generateOrderSummary(cartItems) {
        let summary = "Order Summary:\n\n";
        let total = 0;
        if (cartItems.length === 0) {
            summary += "Your cart is empty.";
        } else {
            cartItems.forEach(item => {
                const itemTotal = item.quantity * item.price;
                summary += `${item.name} (Qty: ${item.quantity}) - $${itemTotal.toFixed(2)}\n`;
                total += itemTotal;
            });
            summary += `\nTotal: $${total.toFixed(2)}`;
        }
        return summary;
    }

    // New function to display completed orders
    function displayCompletedOrders() {
        if (completedOrders.length === 0) {
            completedOrdersContainer.innerHTML = '<p style="text-align: center; color: var(--text-gray);">No orders have been placed yet.</p>';
        } else {
            completedOrdersContainer.innerHTML = ''; // Clear previous content
            completedOrders.forEach((order, index) => {
                const orderElement = document.createElement('div');
                orderElement.classList.add('product-card'); // Re-using the product-card class for styling
                orderElement.style.textAlign = 'left';
                orderElement.innerHTML = `
                    <h3>Order #${index + 1}</h3>
                    <p style="font-size: 0.9rem; color: var(--text-gray);">Placed: ${order.date}</p>
                    <pre style="white-space: pre-wrap; margin-top: 15px; font-size: 0.9rem; color: var(--text-light);">${order.summary}</pre>
                `;
                completedOrdersContainer.appendChild(orderElement);
            });
        }
    }

    // Category Tabs Functionality
    const categoryTabButtons = document.querySelectorAll('.category-tab-btn');
    const categoryContents = document.querySelectorAll('.category-content');

    categoryTabButtons.forEach(button => {
        button.addEventListener('click', () => {
            categoryTabButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            
            categoryContents.forEach(content => content.classList.remove('active'));
            const targetCategory = button.getAttribute('data-category');
            document.getElementById(targetCategory).classList.add('active');
        });
    });
    
    // Sports Sub-Tabs Functionality
    const sportsTabButtons = document.querySelectorAll('.sports-tab-btn');
    const sportsContents = document.querySelectorAll('.sports-category-content');
    
    sportsTabButtons.forEach(button => {
        button.addEventListener('click', () => {
            sportsTabButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            
            sportsContents.forEach(content => content.classList.remove('active'));
            const targetSport = button.getAttribute('data-sport');
            document.getElementById(targetSport).classList.add('active');
        });
    });

    // Modal Functionality
    openModalBtn.addEventListener('click', () => {
        orderModal.classList.add('active');
    });

    closeOrderModalBtn.addEventListener('click', () => {
        orderModal.classList.remove('active');
    });

    closeSubscribeBtn.addEventListener('click', () => {
        subscribeModal.classList.remove('active');
    });
    
    // Close modals when clicking outside of them
    window.addEventListener('click', (event) => {
        if (event.target === orderModal) {
            orderModal.classList.remove('active');
        }
        if (event.target === subscribeModal) {
            subscribeModal.classList.remove('active');
        }
    });

    // Form Submission
    orderForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (cart.length === 0) {
            alert("Your cart is empty. Please add items before checking out.");
            return;
        }
        
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const address = document.getElementById('address').value;

        // Generate the order summary
        const orderSummaryText = generateOrderSummary(cart);
        
        // Add the order to the completedOrders array
        completedOrders.push({
            summary: orderSummaryText,
            date: new Date().toLocaleString()
        });
        displayCompletedOrders(); // Update the orders section

        alert(`
            Order Confirmed!
            
            Thank you, ${name}! Your order has been placed.
            A confirmation email will be sent to ${email}.
            
            ---
            
${orderSummaryText}
        `);
        
        // Show subscribe modal after order is completed
        orderModal.classList.remove('active');
        subscribeModal.classList.add('active');

        // Reset cart and form after submission
        cart = [];
        updateCartDisplay();
        orderForm.reset();
    });

    subscribeForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = document.getElementById('subscribeEmail').value;
        alert(`Thank you for subscribing, ${email}!`);
        subscribeModal.classList.remove('active');
        subscribeForm.reset();
    });

    // Account Form Logic
    if (showSignupLink) {
        showSignupLink.addEventListener('click', (e) => {
            e.preventDefault();
            loginFormWrapper.classList.add('hidden');
            signupFormWrapper.classList.remove('hidden');
        });
    }

    if (showLoginLink) {
        showLoginLink.addEventListener('click', (e) => {
            e.preventDefault();
            signupFormWrapper.classList.add('hidden');
            loginFormWrapper.classList.remove('hidden');
        });
    }
});